<?php 
$flag ="flag not here!";

// flag{92853051ab894a64f7865cf3c2128b34};
 