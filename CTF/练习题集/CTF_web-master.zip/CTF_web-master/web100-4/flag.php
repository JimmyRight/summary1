<?php
$flag = "flag{unserialize_by_virink}";
?>