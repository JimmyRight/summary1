#### 朋友出的一个很好玩的xss题目 

收集在这里

wirteup这里[writeup](./writeup)