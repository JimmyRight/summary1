<?php header("X-XSS-Protection: 0") ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="gb2312">
    <title>Web-ctf</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="hetian ctf ">

    <!-- Le styles -->
    <link href="/css/bootstrap.css" rel="stylesheet">

    <style type="text/css">
        body {
            padding-top: 60px;
            padding-bottom: 40px;
        }
    </style>
    <link href="/css/bootstrap-responsive.css" rel="stylesheet">

</head>

<body>

<div class="navbar navbar-inverse navbar-fixed-top">
    <div class="navbar-inner">
        <div class="container">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <!--a class="brand" href="https://hetianlab.com/">www.hetianlab.com</a-->
            <div class="nav-collapse collapse">
                <ul class="nav">
                    <li class="active"><a href="/">首页</a></li>
                </ul>
            </div><!--/.nav-collapse -->
        </div>
    </div>
</div>

<div class="container">



