<footer>
    <p>&copy; hetian lab</p>
</footer>

</div> <!-- /container -->


</body>
</html>


