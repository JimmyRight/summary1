﻿<?php
	$flag = '_TheCTFinFebisWonderful_';
?>