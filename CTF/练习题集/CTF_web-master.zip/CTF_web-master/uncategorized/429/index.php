<?php

ini_set('session.serialize_handler', 'php');

require("./class.php");

session_start();
// $_SESSION['get']=$_GET['id'];

// var_dump($_SESSION);

// $testobj3=new foo3();
// $testobj3->varr='system("ls");';

// $testobj2=new foo2();
// $testobj2->obj=$testobj3;

// $obj = new foo1();
// $obj->varr =$testobj2;

// echo serialize($obj);

?>



