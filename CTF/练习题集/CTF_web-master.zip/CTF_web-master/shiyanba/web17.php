<?php 

$he ='goodluck';

$he="goodluck";
$flag = "{this_is_flag}"; 


parse_str($_GET['heetian']);

if ($he =="abcd"){
  echo $flag;

}

#
