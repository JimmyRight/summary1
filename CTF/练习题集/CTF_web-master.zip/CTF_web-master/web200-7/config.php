<?php
$option='$option=';phpinfo();';';
