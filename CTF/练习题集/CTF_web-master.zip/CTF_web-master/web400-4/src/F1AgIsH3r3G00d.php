<?php
$flag = "flag{f1a4628ee1e9dccfdc511f0490c73397}";